This product is actively developed by the Linq2Chart team assigned to the Microsoft Open Technologies Hub and in collaboration with a community of open source developers. MS Open Tech is a subsidiary of Microsoft Corp.

## About Linq2Charts

Many data-centric applications need to visualize their results using charts. LINQ-to-Charts is a thin wrapper on top of the [System.Windows.Forms.DataVisualization.Charting](http://msdn.microsoft.com/en-us/library/system.windows.forms.datavisualization.charting.aspx) namespace that presents a LINQ-friendly and strongly typed compositional API for creating charts for .NET programmers.

We have left the names of types and properties unchanged as much as possible so that most of the  [documentation and samples](http://archive.msdn.microsoft.com/mschart) from the underlying library is still applicable. This project is similar to the [F# Chart library](http://code.msdn.microsoft.com/windowsdesktop/FSharpChart-b59073f5|) but is targeted at C# and VB programmers.

The code comes with a small set of samples that should quickly get you up to speed with writing your own compositional charts. This project is also a good example of how you can create your own custom Rx bindings.

Download the latest binary on NuGet: [ https://nuget.org/packages/Linq2Charts/]( https://nuget.org/packages/Linq2Charts/)