Here is an example of using LINQ with the chart controls:

{code:c#}
var pixels = ColorPoint.Pixels(image);

var copy = from pixel in pixels
                 let y = new System.Linq.Charting.Point.DataPoint(image.Height - pixel.Y) { Color = pixel.Color }
                 let x = pixel.X + 1
                 select KeyValuePair.Create(x, y);

var pixelated = new System.Linq.Charting.Point { Points = { copy } };
{code:c#}
 
There are more examples in the **Samples** directory.