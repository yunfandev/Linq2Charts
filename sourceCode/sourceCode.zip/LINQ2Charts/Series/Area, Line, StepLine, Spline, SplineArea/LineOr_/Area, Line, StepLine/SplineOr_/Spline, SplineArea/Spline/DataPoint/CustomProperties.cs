﻿namespace System.Linq.Charting
{
    partial class Spline 
    {
        partial class DataPoint
        {
        }
    }
}
