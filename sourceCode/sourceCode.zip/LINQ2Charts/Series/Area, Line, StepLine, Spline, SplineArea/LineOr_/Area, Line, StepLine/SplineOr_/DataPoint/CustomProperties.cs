﻿namespace System.Linq.Charting
{
    partial class SplineOr_<S>
    {
        partial class DataPoint
        {
        }
    }
}
