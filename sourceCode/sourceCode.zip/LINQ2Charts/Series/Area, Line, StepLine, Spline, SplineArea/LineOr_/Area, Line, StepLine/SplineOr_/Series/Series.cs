﻿namespace System.Linq.Charting
{
    public abstract partial class SplineOr_<S> : LineOr_<S> where S : SplineOr_<S>.DataPoint
    {
        protected SplineOr_()
        {
        }
    }

}
