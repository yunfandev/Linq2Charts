﻿namespace System.Linq.Charting
{
    partial class SplineOr_<S>
    {
        public abstract new partial class DataPoint : LineOr_<S>.DataPoint
        {
            protected DataPoint(object value) : base(value) { }
        }
    }

}
