﻿namespace System.Linq.Charting
{
    partial class SplineArea
    {
    }
}
