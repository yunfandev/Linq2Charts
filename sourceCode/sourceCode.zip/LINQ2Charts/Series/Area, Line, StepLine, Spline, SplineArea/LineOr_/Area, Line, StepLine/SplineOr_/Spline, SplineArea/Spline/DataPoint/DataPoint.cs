﻿namespace System.Linq.Charting
{
    partial class Spline 
    {
        public new partial class DataPoint : SplineOr_<DataPoint>.DataPoint
        {
            public DataPoint(object value) : base(value) { }
        }
    }

}
