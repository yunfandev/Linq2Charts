﻿namespace System.Linq.Charting
{
    partial class SplineArea 
    {
        partial class DataPoint
        {
        }
    }
}
