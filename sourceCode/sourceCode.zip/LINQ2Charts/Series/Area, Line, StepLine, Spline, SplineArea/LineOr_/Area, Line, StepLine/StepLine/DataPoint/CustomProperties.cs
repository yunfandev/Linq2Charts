﻿namespace System.Linq.Charting
{
    partial class StepLine 
    {
        partial class DataPoint 
        {
        }
    }

}
