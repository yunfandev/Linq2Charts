﻿namespace System.Linq.Charting
{
    partial class StepLine 
    {
        public new partial class DataPoint : LineOr_<DataPoint>.DataPoint
        {
            public DataPoint(object value) : base(value) { }
        }
    }

}
