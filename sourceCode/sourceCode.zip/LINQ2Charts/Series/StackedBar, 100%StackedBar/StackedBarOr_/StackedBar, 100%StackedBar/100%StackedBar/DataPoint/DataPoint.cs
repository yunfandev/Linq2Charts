﻿// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

namespace System.Linq.Charting
{
    partial class StackedBar100
    {
        public new partial class DataPoint : StackedBarOr_<DataPoint>.DataPoint
        {
            public DataPoint(object value) : base(value) { }
        }
    }

}
