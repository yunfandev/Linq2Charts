﻿// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

namespace System.Linq.Charting
{
    public abstract partial class StackedBarOr_<S> : Series<S> where S : StackedBarOr_<S>.DataPoint
    {
        protected StackedBarOr_()
        {
        }
    }

}
